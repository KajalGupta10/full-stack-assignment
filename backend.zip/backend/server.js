require('dotenv').config(); // Environment variables लोड करें
const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');

// Initialize Express app
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Supabase कनेक्शन
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

// Slack Webhook URL
const SLACK_WEBHOOK = process.env.SLACK_WEBHOOK;

// ----------------------
// Todo Routes
// ----------------------

// GET /api/todos - सभी टोडो फ़ेच करें
app.get('/api/todos', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('todos')
      .select('*');
    
    if (error) throw error;
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch todos' });
  }
});

// POST /api/todos - नया टोडो जोड़ें
app.post('/api/todos', async (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'Text is required' });

  try {
    const { data, error } = await supabase
      .from('todos')
      .insert([{ text }])
      .select();
    
    if (error) throw error;
    res.status(201).json(data[0]);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create todo' });
  }
});

// DELETE /api/todos/:id - टोडो डिलीट करें
app.delete('/api/todos/:id', async (req, res) => {
  try {
    const { error } = await supabase
      .from('todos')
      .delete()
      .eq('id', req.params.id);
    
    if (error) throw error;
    res.sendStatus(204);
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete todo' });
  }
});

// ----------------------
// Summarize Route
// ----------------------

// POST /api/summarize - टोडो सारांश बनाएं और Slack भेजें
app.post('/api/summarize', async (req, res) => {
  try {
    const { todos } = req.body;

    // OpenAI API से सारांश बनाएं
    const prompt = `इन टास्क्स को हिंदी में संक्षेप में बताएं:\n${todos.map(t => `- ${t.text}`).join('\n')}\n\nसारांश:`;
    const openaiResponse = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const summary = openaiResponse.data.choices[0].message.content.trim();

    // Slack पर भेजें
    await axios.post(SLACK_WEBHOOK, { text: summary });
    res.json({ success: true, summary });
  } catch (err) {
    console.error('Summarize Error:', err);
    res.status(500).json({ error: 'सारांश बनाने में असफल' });
  }
});

// सर्वर शुरू करें
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});